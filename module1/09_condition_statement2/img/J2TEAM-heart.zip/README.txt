Mở index.html

Tìm EDIT HERE và thay các chữ trong trang web.

Tìm EDIT_ME.png và thay thành ảnh người yêu của bạn.

---
Theo dõi mình để biết thêm nhiều thứ hấp dẫn khác nhé!

> Tiktok: https://www.tiktok.com/@juno_okyo
> Profile: https://www.facebook.com/100003880469096
> Group: https://www.facebook.com/groups/j2team.community/